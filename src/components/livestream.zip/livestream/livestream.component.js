loadTag('headTag');
window.base = "http://localhost:8000/";
window.resposeDat = [];
bla().then(() => {
    console.log('mystrem' ,window.resposeDat); // Access window.resposeDat after it's updated
});
              
function bla() {
    return new Promise((resolve, reject) => {
        callApi(base + 'api/ls', 'json', 'POST').then(
            data => {
                window.resposeDat = data;
                resolve(); // Resolve the promise after updating window.resposeDat
            }
        ).catch(error => {
            reject(error); // Reject the promise if there's an error
        });
    });
}          

function stop() {
    callApi(base + 'api/lsend', 'json', 'POST').then(
        data => {
            window.resposeDat = data;
            resolve(); // Resolve the promise after updating window.resposeDat
        }
    );
}
                
/***********************Write all JS above this ******************/
updateHtml()
                